package com.lml.democlass.view;


import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.lml.democlass.R;
import com.lml.democlass.utils.Ajax;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.FutureTask;

public class HomeFragment extends Fragment {
    //数据
    int INF=1000000;
    char[][] cs={{'E','E','E','E','E','E','M','E','E','E','E','E','E','E','E','M','E'},{'E','E','M','E','E','E','E','E','E','M','E','E','M','E','E','M','E'},{'E','E','E','E','E','E','E','E','E','E','E','E','E','E','E','E','E'},{'E','E','E','E','E','E','E','E','E','E','E','E','E','E','E','E','E'}};
    TableLayout myTableLayout;
    Context context;
    Button getNewValueButton,begin;
    boolean isStart=false;//是否开始游戏
    Chronometer ch;//计时器
    TextView textView;
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.fragment_home, null);
        init(view);
        return view;
    }

    //初始化
    private void init(View view) {
        myTableLayout = view.findViewById(R.id.myTableLayout);
        getNewValueButton=view.findViewById(R.id.getNewValueButton);
        ch=view.findViewById(R.id.timer);
        begin=view.findViewById(R.id.begin);
        textView=view.findViewById(R.id.number);
        textView.setTextSize(24);
        textView.setTextColor(Color.RED);
        context = getContext();
        initStartButton();
        getNewValue();
        loadData();
    }

    ////监听->开始游戏
    private void initStartButton() {
        begin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ch.setBase(SystemClock.elapsedRealtime());
                ch.start();//开始计时
                begin.setEnabled(false);
                isStart=true;
            }
        });
    }

    //监听->重新开始--获取数据
    private void getNewValue() {
        getNewValueButton.setOnClickListener(v->{
            FutureTask futureTask=new FutureTask(()->
                Ajax.get("/mine-clearance/randomMine")
            );
            new Thread(futureTask).start();
            try {
                //"data":["B1E1B","B1M1B","B111B","BBBBB"]
                String data = (String) futureTask.get();
                if(data!=null){
                    JSONObject jsonObject = new JSONObject(data);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    int n = jsonArray.length();
                    int m = ((String) jsonArray.get(0)).length();
                    cs=new char[n][m];
                    for (int i = 0; i < n; i++) {
                        String s = (String) jsonArray.get(i);
                        for (int j = 0; j < m; j++) {
                            cs[i][j]=s.charAt(j);
                        }
                    }
                    //重新渲染数据
                    loadData();
                    begin.setEnabled(true);
                    isStart=false;
                    //暂停并重置时间为0
                    ch.stop();
                    ch.setBase(SystemClock.elapsedRealtime());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    //渲染数据
    private void loadData() {
        //清除旧数据
        myTableLayout.removeAllViews();
        //雷的个数
        int number=0;
        //方块大小
        int x = 800;
        int maxSize=x/cs[0].length;
        for (int i = 0; i < cs.length; i++) {
            TableRow tableRow = new TableRow(context);
            for (int j = 0; j < cs[i].length; j++) {
                //雷的个数+1
                if(cs[i][j]=='M' || cs[i][j]=='X')number++;
                //未挖出的
                if(cs[i][j]=='M' || cs[i][j]=='E'){
                    loadImageByPath(context, maxSize, tableRow, i,j, R.mipmap.block);
                }else if(cs[i][j]=='X'){//挖出的地雷
                    loadImageByPath(context, maxSize, tableRow, i, j, R.mipmap.zd);
                }else if(cs[i][j]=='B'){//空白
                    loadImageByPath(context, maxSize, tableRow, i, j, R.mipmap.n0);
                }else{
                    //mipmap资源id
                    int mipmapId = getResources().getIdentifier("n"+cs[i][j], "mipmap",context.getPackageName());
                    loadImageByPath(context, maxSize, tableRow, i, j, mipmapId);
                }
            }
            myTableLayout.addView(tableRow,i);
        }
        //显示地雷的个数
        textView.setText("地雷的个数："+number);
    }

    //根据数组初始化图片
    private void loadImageByPath(Context context, int maxSize, TableRow tableRow, int i, int j, int p) {
        ImageView imageView = new ImageView(context);
        imageView.setImageResource(p);
        //设置图片id,从0开始
        imageView.setId(i*cs[0].length+j+INF);
        tableRow.addView(imageView, j);
        imageView.setPadding(2, 2, 2, 2);
        ViewGroup.LayoutParams layoutParams = imageView.getLayoutParams();
        layoutParams.width = maxSize;
        imageView.setLayoutParams(layoutParams);
        imageView.setClickable(true);
        //监听点击事件
        imageView.setOnClickListener((v)->{
            //若果游戏未开始，则退出
            if(!isStart)return;
            int x=(v.getId()-INF)/cs[0].length,y=(v.getId()-INF)%cs[0].length;
            int updateTotal=0;
            //判断是否是未挖出
            if(cs[x][y]=='E'){
                //修改数组
                updateBoard(cs,x,y);
                //判断是否通关
                if(isSuccess()){
                    //通关
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle("成功");
                    builder.setMessage("恭喜你成功通关");
                    builder.show();
                    updateTotal++;
                }
                //重新渲染数据
                loadData();
            }else if(cs[x][y]=='M'){//点到未挖出的地雷
                updateBoard(cs,x,y);
                //重新渲染数据
                loadData();
                //游戏失败
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("失败");
                builder.setMessage("挑战失败");
                builder.show();
                updateTotal--;
            }
            // 游戏结束
            if(updateTotal!=0){
                //停止计时器
                ch.stop();
                int finalUpdateTotal = updateTotal;
                //保存用户数据
                new Thread(()->{
                    SharedPreferences sharedPreferences = context.getSharedPreferences("user", Context.MODE_PRIVATE);
                    String id = sharedPreferences.getString("id", null);
                    //如果用户没有登录则不记录游戏信息
                    if(id!=null){
                        JSONObject param = new JSONObject();
                        try {
                            param.put("id",id);
                            param.put("updateTotal", finalUpdateTotal);
                            param.put("minTime", ch.getText().toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        //修改数据库信息
                        Ajax.post(param,"/user/updateUser");
                        //修改本地信息
                        SharedPreferences.Editor edit = sharedPreferences.edit();
                        edit.putString("total",Integer.parseInt(sharedPreferences.getString("total","0"))+1+"");
                        if(finalUpdateTotal>0){
                            edit.putString("successTotal",Integer.parseInt(sharedPreferences.getString("successTotal","0"))+1+"");
                            edit.putString("minTime",ch.getText().toString());
                        }
                        edit.commit();
                    }
                }).start();
            }
        });
    }
    //判断是否成功
    private boolean isSuccess() {
        for (int i = 0; i < cs.length; i++) {
            for (int j = 0; j < cs[i].length; j++) {
                if(cs[i][j]=='E'){
                    //还有未点击的方块
                    return false;
                }
            }
        }
        return true;
    }

    int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
    int n=0,m=0;
    boolean[][] vis;
    //用户点击后触发事件--修改数组
    public char[][] updateBoard(char[][] board, int x,int y) {
        n=board.length;m=board[0].length;
        vis=new boolean[n][m];
        if(board[x][y]=='M'){
            board[x][y]='X';
        } else dfs(board,x,y);
        return board;
    }
    private void dfs(char[][] board, int i, int j) {
        if(vis[i][j])return;
        int s=0;
        vis[i][j]=true;
        ArrayList<int[]> nextList = new ArrayList<>();
        for (int[] dir : dirs) {
            int x=dir[0]+i,y=dir[1]+j;
            if(x<0 || y<0 || x>=n || y>=m || vis[x][y])continue;
            if(board[x][y]=='M' || board[x][y]=='X'){
                s++;
            } else if(!vis[x][y]){
                nextList.add(new int[]{x,y});
            }
        }
        if(board[i][j]!='M' && board[i][j]!='X')board[i][j]= s==0?'B': (char) (s + '0');
        if(s>0)return;
        for (int[] next : nextList) {
            dfs(board,next[0],next[1]);
        }
    }

}
