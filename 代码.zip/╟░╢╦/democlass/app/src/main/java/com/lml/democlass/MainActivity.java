package com.lml.democlass;

import androidx.appcompat.app.AppCompatActivity;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.lml.democlass.view.HomeFragment;
import com.lml.democlass.view.MeFragment;
import com.lml.democlass.view.RankFragment;

public class MainActivity extends AppCompatActivity {

    FrameLayout frameLayout;
    LinearLayout router;
    Button home,me,ranking;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frameLayout = findViewById(R.id.main_fragment);
        home = findViewById(R.id.rb_home);
        router = findViewById(R.id.router);
        ranking=findViewById(R.id.rb_ranking);
        me = findViewById(R.id.rb_me);
        initView();
    }

    private void initView() {
        //默认首页
        HomeFragment homeFragment = new HomeFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.main_fragment,homeFragment).commit();
        //绑定跳转
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomeFragment homeFragment = new HomeFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.main_fragment,homeFragment).commit();
            }
        });
        me.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MeFragment meFragment = new MeFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.main_fragment,meFragment).commit();
            }
        });
        ranking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RankFragment rankFragment = new RankFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.main_fragment,rankFragment).commit();
            }
        });
    }
}
