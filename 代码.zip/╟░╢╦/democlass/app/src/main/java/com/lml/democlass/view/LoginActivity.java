package com.lml.democlass.view;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.lml.democlass.MainActivity;
import com.lml.democlass.R;
import com.lml.democlass.utils.Ajax;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.concurrent.FutureTask;

public class LoginActivity extends AppCompatActivity {
    private EditText etAccount,etPassword;
    private String userName="a";
    private String pass="123";
    private Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setTitle("登录");
        init();
    }
    private void init() {
        etAccount=findViewById(R.id.et_account);
        etPassword=findViewById(R.id.et_password);
        context=this;
    }

    //登录
    public void login(View view){
        userName=etAccount.getText().toString();
        pass=etPassword.getText().toString();
        FutureTask futureTask=new FutureTask(()->{
            try {
                JSONObject param = new JSONObject();
                param.put("username",userName);
                param.put("password",pass);
                String result = Ajax.post(param,"/user/login");
                JSONObject ans = new JSONObject(result);
                JSONObject data = ans.getJSONObject("data");
                return data;
            } catch (Exception e) {
                return null;
            }
        });
        new Thread(futureTask).start();
        JSONObject data=null;
        try {
            // {"msg":"success","code":0,"data":null}
            data = (JSONObject) futureTask.get();
            if(data==null){
                //用户名或者密码有误
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("错误");
                builder.setMessage("用户名或者密码有误");
                builder.setPositiveButton("确定",null);
                builder.show();
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //Context.MODE_PRIVATE 覆盖原有内容
        SharedPreferences sharedPreferences = context.getSharedPreferences("user", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sharedPreferences.edit();
        try {
            edit.putString("id",data.getString("id"));
            edit.putString("username",data.getString("username"));
            edit.putString("password",data.getString("password"));
            edit.putString("total",data.getString("total"));
            edit.putString("successTotal",data.getString("successTotal"));
            edit.putString("minTime",data.getString("minTime"));
            edit.commit();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Intent intent = new Intent();
        intent.setClass(this, MainActivity.class);
        startActivity(intent);
    }

    //跳转注册页面
    public void toRegister(View view){
        Intent intent = new Intent();
        intent.setClass(this, RegisterActivity.class);
        startActivity(intent);
    }

}
