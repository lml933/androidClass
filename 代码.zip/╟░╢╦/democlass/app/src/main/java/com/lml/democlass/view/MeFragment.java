package com.lml.democlass.view;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.lml.democlass.MainActivity;
import com.lml.democlass.R;

public class MeFragment extends Fragment {
    TextView me_username,me_successTotal,me_total,me_minTime;
    Context context;
    LinearLayout linearLayout;
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.fragment_me, null);
        init(view);
        //检查是否登录
        initCheck(linearLayout,view);
        //渲染用户数据
        loadUser();
        return view;
    }

    private void loadUser() {
        SharedPreferences sharedPreferences = context.getSharedPreferences("user", Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("username", "");
        String total = sharedPreferences.getString("total", "");
        String successTotal = sharedPreferences.getString("successTotal", "");
        String minTime = sharedPreferences.getString("minTime", "");
        me_username.setText(username);
        me_total.setText(total);
        me_successTotal.setText(successTotal);
        me_minTime.setText(minTime);
    }

    private void init(View view) {
        context = getContext();
        linearLayout = view.findViewById(R.id.me_main);
        me_username = view.findViewById(R.id.me_username);
        me_successTotal = view.findViewById(R.id.me_successTotal);
        me_total = view.findViewById(R.id.me_total);
        me_minTime=view.findViewById(R.id.me_minTime);
    }

    //检查是否登录
    private void initCheck(LinearLayout linearLayout,View view) {
//        第一个参数是存储时的名称，第二个参数则是文件的打开方式~
        SharedPreferences sharedPreferences = context.getSharedPreferences("user", Context.MODE_PRIVATE);
        String userId = sharedPreferences.getString("id", null);//(key,若无数据需要赋的值)
        if(userId==null || userId.isEmpty()){
            //还没登录
            Button button = new Button(context);
            button.setText("请先登录");
            button.setTextColor(0xFFFF0000);
            button.setOnClickListener((v)->{
                //跳转到登录
                Intent intent = new Intent();
                intent.setClass(context, LoginActivity.class);
                startActivity(intent);
            });
            linearLayout.addView(button);
        }else{
            //显示退出登录按钮
            Button button = new Button(context);
            button.setText("退出登录");
            button.setTextColor(0xFFFF0000);
            button.setOnClickListener((v -> {
                SharedPreferences.Editor edit = sharedPreferences.edit();
                edit.remove("id");
                edit.remove("username");
                edit.remove("password");
                edit.remove("total");
                edit.remove("successTotal");
                edit.remove("minTime");
                edit.commit();
                Intent intent = new Intent();
                intent.setClass(context, MainActivity.class);
                startActivity(intent);
            }));
            //显示修改用户信息按钮
            Button button2 = new Button(context);
            button2.setText("修改");
            button2.setTextColor(Color.BLACK);
            button2.setOnClickListener((v)->{
                // 跳转修改用户信息页
                Intent intent = new Intent();
                intent.setClass(context, UpdateUserActivity.class);
                startActivity(intent);
            });
            linearLayout.addView(button);
            linearLayout.addView(button2);
        }
    }
}
