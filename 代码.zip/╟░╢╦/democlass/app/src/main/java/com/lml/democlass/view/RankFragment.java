package com.lml.democlass.view;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.lml.democlass.MainActivity;
import com.lml.democlass.R;
import com.lml.democlass.utils.Ajax;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.FutureTask;

public class RankFragment extends Fragment {
    Context context;
    ListView listView;
    String[] vs={};
    ArrayAdapter<String> adapter;
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.fragment_rank, null);
        init(view);
        load();
        return view;
    }

    //获取数据
    private void load() {
        FutureTask futureTask=new FutureTask(()->{
            try {
                JSONObject jsonObject = new JSONObject(Ajax.get("/user/rankList"));
                //[{"id":1,"username":"aaa","password":"123","total":10,"successTotal":8},
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                System.out.println(jsonObject);
                vs=new String[jsonArray.length()];
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject object = jsonArray.getJSONObject(i);
                    vs[i]="第"+(i+1)+"名："+object.getString("username")+"     总场数：";
                    vs[i]+=object.getString("total")+"\n通关场数：";
                    vs[i]+=object.getString("successTotal")+"    最短通关时间：";
                    vs[i]+=object.getString("minTime");
                }
                return vs;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        });
        new Thread(futureTask).start();
        try {
            vs = (String[])futureTask.get();
            adapter = new ArrayAdapter<String>(context,android.R.layout.simple_list_item_1,vs);
            listView.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void init(View view) {
        context = getContext();
        listView = view.findViewById(R.id.rank_list);
    }

}
