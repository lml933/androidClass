package com.lml.democlass.utils;

import android.util.Log;

import org.json.JSONObject;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Ajax {
    public static String bashUrl="http://192.168.111.1:9000";
    public static OkHttpClient okHttpClient=new OkHttpClient();
    public static String get(String url) {
        Request request = new Request.Builder().url(bashUrl+url).build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            if (response.isSuccessful()) {
                String result = response.body().string();
                return result;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static String post(JSONObject param, String url){
        RequestBody requestBody = FormBody.create(MediaType.parse("application/json; charset=utf-8"), param.toString());
        try{
            Request request = new Request.Builder().url(bashUrl+url).post(requestBody).build();
            try (Response response = okHttpClient.newCall(request).execute()) {
                String result = response.body().string();
                return result;
            }catch (Exception e){
                throw e;
            }
        }catch (Exception e){
            String result = "{'flag':0,'message':'" + e.toString() + "'}";
            return result;
        }
    }
}
