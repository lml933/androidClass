package com.lml.democlass.view;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.lml.democlass.MainActivity;
import com.lml.democlass.R;
import com.lml.democlass.utils.Ajax;
import com.lml.democlass.utils.StringUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.FutureTask;

public class UpdateUserActivity extends AppCompatActivity {
    private EditText etUserName,etPassword,etPasswordConfirm;
    private String userName="";
    private String pass="",passConfirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updateuser);
        getSupportActionBar().setTitle("修改用户信息");
        init();
    }

    private void init() {
        etUserName=findViewById(R.id.et_userName);
        etPassword=findViewById(R.id.et_password);
        etPasswordConfirm=findViewById(R.id.et_password_Confirm);
    }
    //修改方法
    public void registerUser(View view){
        userName=etUserName.getText().toString();
        pass=etPassword.getText().toString();
        passConfirm=etPasswordConfirm.getText().toString();
        SharedPreferences sharedPreferences = this.getSharedPreferences("user", Context.MODE_PRIVATE);
        if(checkRegister(sharedPreferences)){
            //信息合法
            //修改用户信息
            FutureTask futureTask=new FutureTask(()->{
                try {
                    JSONObject param = new JSONObject();
                    param.put("id",sharedPreferences.getString("id",""));
                    param.put("username",userName);
                    param.put("password",pass);
                    String result = Ajax.post(param,"/user/updateUserMessage");
                    JSONObject ans = new JSONObject(result);
                    JSONObject data = ans.getJSONObject("data");
                    return data;
                } catch (Exception e) {
                    return null;
                }
            });
            new Thread(futureTask).start();
            JSONObject data=null;
            try {
                data = (JSONObject) futureTask.get();
                if(data==null){
                    //修改失败
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("错误");
                    builder.setMessage("修改失败");
                    builder.setPositiveButton("确定",null);
                    builder.show();
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            //保存用户信息
            SharedPreferences.Editor edit = sharedPreferences.edit();
            try {
                //清空旧信息
                edit.clear();
                edit.commit();
                edit.putString("id",data.getString("id"));
                edit.putString("username",data.getString("username"));
                edit.putString("password",data.getString("password"));
                edit.putString("total",data.getString("total"));
                edit.putString("successTotal",data.getString("successTotal"));
                edit.commit();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            // 跳转
            Intent intent = new Intent();
            intent.setClass(this, MainActivity.class);
            startActivity(intent);
        }
    }

    //检查注册信息
    private boolean checkRegister(SharedPreferences sharedPreferences) {
        if(StringUtils.isEmpty(userName)
                || StringUtils.isEmpty(pass)
                || StringUtils.isEmpty(passConfirm)
                || !pass.equals(passConfirm)
                || sharedPreferences.getString("id","").equals("")){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("错误");
            builder.setMessage("用户名和密码不能为空,或者用户名已经重复,或者登录信息已经过期");
            builder.setPositiveButton("确定",null);
            builder.show();
            return false;
        }
        return true;
    }
    //返回主页面
    public void returnMain(View view){
        // 跳转到首页
        Intent intent = new Intent();
        intent.setClass(this, MainActivity.class);
        startActivity(intent);
    }

}
