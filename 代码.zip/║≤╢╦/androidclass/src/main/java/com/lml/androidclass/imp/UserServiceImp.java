package com.lml.androidclass.imp;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lml.androidclass.entity.User;
import com.lml.androidclass.mapper.UserMapper;
import com.lml.androidclass.service.UserService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author lml
 * @since 2022-05-13
 */
@Service
public class UserServiceImp extends ServiceImpl<UserMapper, User> implements UserService {

    @Override
    public User getUserByUser(User user) {
        String username = user.getUsername();
        String password = user.getPassword();
        User ansUser = baseMapper.selectOne(new QueryWrapper<User>()
                .eq("username", username)
                .and(w -> {
                    w.eq("password", password);
                }));
        return ansUser;
    }

    @Override
    public User getUserByUserName(User user) {
        String username = user.getUsername();
        User ansUser = baseMapper.selectOne(new QueryWrapper<User>()
                .eq("username", username));
        return ansUser;
    }
}
