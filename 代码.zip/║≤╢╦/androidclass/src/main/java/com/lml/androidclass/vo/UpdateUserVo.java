package com.lml.androidclass.vo;

public class UpdateUserVo {
    private Integer id;
    private Integer updateTotal;
    private String minTime;
    public String getMinTime() {
        return minTime;
    }

    public void setMinTime(String minTime) {
        this.minTime = minTime;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }

    public void setUpdateTotal(Integer updateTotal) {
        this.updateTotal = updateTotal;
    }
    public Integer getUpdateTotal() {
        return updateTotal;
    }

}
