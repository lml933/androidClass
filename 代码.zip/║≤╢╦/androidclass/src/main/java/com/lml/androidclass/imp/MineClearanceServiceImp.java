package com.lml.androidclass.imp;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lml.androidclass.entity.MineClearance;
import com.lml.androidclass.mapper.MineClearanceMapper;
import com.lml.androidclass.service.MineClearanceService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author lml
 * @since 2022-05-13
 */
@Service
public class MineClearanceServiceImp extends ServiceImpl<MineClearanceMapper, MineClearance> implements MineClearanceService {

    @Override
    public char[][] randomMine() {
        List<MineClearance> list = baseMapper.selectList(null);
        Random random = new Random();
        int index = random.nextInt(list.size());
        MineClearance target = list.get(index);
        String block = target.getBlock();
        String[] ns = block.split("n");
        char[][] ans = new char[ns.length][ns[0].length()];
        for (int i = 0; i < ns.length; i++) {
            for (int j = 0; j < ns[0].length(); j++) {
                ans[i][j]=ns[i].charAt(j);
            }
        }
        return ans;
    }
}
