package com.lml.androidclass.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.lml.androidclass.entity.User;
import com.lml.androidclass.service.UserService;
import com.lml.androidclass.utils.R;
import com.lml.androidclass.vo.UpdateUserVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author lml
 * @since 2022-05-13
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/login")
    public R login(@RequestBody User user){
        User ansUser=userService.getUserByUser(user);
        return R.ok().put("data",ansUser);
    }
    //注册用户
    @PostMapping("/register")
    public R registerUser(@RequestBody User user){
        User repeatUser=userService.getUserByUserName(user);
        //用户名重复
        if(repeatUser!=null)return R.error();
        userService.save(user);
        User ansUser=userService.getUserByUser(user);
        return R.ok().put("data",ansUser);
    }
    //修改用户游戏信息
    @PostMapping("/updateUser")
    public R updateUser(@RequestBody UpdateUserVo updateUserVo){
        User user = userService.getById(updateUserVo.getId());
        user.setTotal(user.getTotal()+1);
        if(updateUserVo.getUpdateTotal()>0){
            //成功通关
            //修改最短通关时间
            String[] s1 = user.getMinTime().split(":");
            String[] s2 = updateUserVo.getMinTime().split(":");
            int minute1 = Integer.parseInt(s1[0]),minute2=Integer.parseInt(s2[0]);
            int second1 = Integer.parseInt(s1[1]),second2=Integer.parseInt(s2[1]);
            if(minute1>minute2 || (minute1==minute2 && second1>second2)){
                //分钟新值更小，或者分钟相同秒值更小
                user.setMinTime(updateUserVo.getMinTime());
            }
            //修改成功通关次数
            user.setSuccessTotal(user.getSuccessTotal()+1);
        }
        userService.updateById(user);
        return R.ok();
    }
    //修改用户个人信息
    @PostMapping("/updateUserMessage")
    public R updateUserMessage(@RequestBody User user){
        User repeatUser=userService.getUserByUserName(user);
        //用户名重复
        if(repeatUser!=null)return R.error();
        userService.updateById(user);
        User ansUser=userService.getUserByUser(user);
        return R.ok().put("data",ansUser);
    }
    //获取排行榜
    @GetMapping("/rankList")
    public R rankList(){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.orderByDesc("success_total");
        wrapper.orderByAsc("total");
        wrapper.last("limit 10");
        List<User> list = userService.list(wrapper);
        return R.ok().put("data",list);
    }
}
