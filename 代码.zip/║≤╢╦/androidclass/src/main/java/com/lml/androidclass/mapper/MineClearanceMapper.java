package com.lml.androidclass.mapper;

import com.lml.androidclass.entity.MineClearance;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lml
 * @since 2022-05-13
 */
@Mapper
public interface MineClearanceMapper extends BaseMapper<MineClearance> {

}
