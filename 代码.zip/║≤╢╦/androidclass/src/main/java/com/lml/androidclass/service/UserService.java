package com.lml.androidclass.service;

import com.lml.androidclass.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lml
 * @since 2022-05-13
 */
public interface UserService extends IService<User> {

    User getUserByUser(User user);

    User getUserByUserName(User user);
}
