package com.lml.androidclass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AndroidclassApplication {

    public static void main(String[] args) {
        SpringApplication.run(AndroidclassApplication.class, args);

    }

}
