package com.lml.androidclass.controller;


import com.lml.androidclass.service.MineClearanceService;
import com.lml.androidclass.utils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author lml
 * @since 2022-05-13
 */
@RestController
@RequestMapping("/mine-clearance")
public class MineClearanceController {

    @Autowired
    MineClearanceService mineClearanceService;

    @GetMapping("/randomMine")
    public R randomMine(){
        char[][] ans = mineClearanceService.randomMine();
        return R.ok().put("data",ans);
    }
}
