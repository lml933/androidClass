package com.lml.androidclass;

import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Collections;

@SpringBootTest
class AndroidclassApplicationTests {

    @Test
    void contextLoads() {
        FastAutoGenerator.create("jdbc:mysql://192.168.0.107:3306/android?useUnicode=true&useSSL=false&characterEncoding=utf8", "root", "root")
                .globalConfig(builder -> {
                    builder.author("lml") // 设置作者
//                            .enableSwagger() // 开启 swagger 模式  可理解为接口文档规范
                            .fileOverride() // 覆盖已生成文件
                            .outputDir(System.getProperty("user.dir") + "/src/main/java"); // 指定输出目录
                })
                .packageConfig(builder -> {
                    builder.parent("com.lml.androidclass") // 设置父包名
                            .moduleName("") // 设置父包模块名
                            .entity("entity")
                            .controller("controller")
                            .service("service")
                            .serviceImpl("imp") //设置包名
                            .pathInfo(Collections.singletonMap(OutputFile.mapperXml, System.getProperty("user.dir") + "/src/main/resources/mapper/")); // 设置mapperXml生成路径
                })
                .strategyConfig(builder -> {
//                    builder.addInclude("表名")// 设置需要生成的表名 不使用该方法默认生成全表
                    builder.addInclude("province")
                            .addTablePrefix("t_", "c_") // 设置过滤表前缀ad_class
                            .serviceBuilder()//Service配置
                            .formatServiceFileName("%sService")//%s = 表名  表名Service
                            .formatServiceImplFileName("%sServiceImp")//同上
                            .entityBuilder()//实体类配置 一般都是表名
//                            .enableLombok()//开启Lombok 开启 swagger 模式 就没必要使用这个
//                            .logicDeleteColumnName()//逻辑删除字段对应数据库那个字段
//                            .logicDeletePropertyName()//逻辑删除字段对应实体类库那个字段
                            .controllerBuilder()//Controller配置
                            .formatFileName("%sController")
                            .enableRestStyle()//开启生成@RestController控制器
                            .mapperBuilder()//mapper配置
                            .formatMapperFileName("%sMapper")
                            .formatXmlFileName("%sMapper")
                            .enableMapperAnnotation();//开启@Mapper;
                })
                // 使用Freemarker引擎模板，默认的是Velocity引擎模板
                .templateEngine(new FreemarkerTemplateEngine())
                .execute();

    }
}
