/*
 Navicat Premium Data Transfer

 Source Server         : lml
 Source Server Type    : MySQL
 Source Server Version : 50536
 Source Host           : localhost:3306
 Source Schema         : android

 Target Server Type    : MySQL
 Target Server Version : 50536
 File Encoding         : 65001

 Date: 15/06/2022 22:46:45
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for mine_clearance
-- ----------------------------
DROP TABLE IF EXISTS `mine_clearance`;
CREATE TABLE `mine_clearance`  (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `block` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mine_clearance
-- ----------------------------
INSERT INTO `mine_clearance` VALUES (1, 'EEMEEnMEMEEnEEEMEnEEEEE');
INSERT INTO `mine_clearance` VALUES (3, 'EEEEEEMEMEnEEMEEEEMEEnEEEMEMEEEEnEMEEEEEEEE');
INSERT INTO `mine_clearance` VALUES (4, 'EEMMEEEMMEnMEEMEEEEEEnEEMMMEEMMEnEEEMEEEEMEnEEEMEEEMEEn');
INSERT INTO `mine_clearance` VALUES (5, 'EEMEEMEnMEMEEMEnEEEMEMEnEEEEEME');
INSERT INTO `mine_clearance` VALUES (6, 'EEMEEMEnMEMEEMEnEEEMEMEnEEEMEMEnEEEMEMEnEEEMEMEn');
INSERT INTO `mine_clearance` VALUES (7, 'EEEEnEMEEnEEEEnEEEE');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `total` int(50) NULL DEFAULT 0,
  `success_total` int(255) NULL DEFAULT 0,
  `min_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '99:99',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'aa', '12', 25, 16, '00:02');
INSERT INTO `user` VALUES (4, 'bbb', '123', 3, 2, '99:99');
INSERT INTO `user` VALUES (5, 'ccc', '123', 2, 2, '10:99');
INSERT INTO `user` VALUES (6, 'ddd', '123', 2, 1, '99:99');

SET FOREIGN_KEY_CHECKS = 1;
